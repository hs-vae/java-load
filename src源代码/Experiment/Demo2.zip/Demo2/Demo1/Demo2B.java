package Experiment.Demo2.Demo1;

import Advanced.JDBC.Util.DBUtils;

import java.sql.SQLException;

public class Demo2B {
    public static void main(String[] args) {
        DBUtils db=new DBUtils();
        try {
            //获取连接
            db.getConnection();
            //定义sql语句,要求删除9月1日之前注册的会员信息
            String sql="delete from ms_memer where Regtime<? ";
            db.executeUpdate(sql,new String[]{"2020-08-31 23:59:59"});
            System.out.println("已成功删除9月1日前注册的会员信息");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            db.closeAll();
        }
    }
}
