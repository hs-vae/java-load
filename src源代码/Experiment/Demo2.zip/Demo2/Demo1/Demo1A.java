package Experiment.Demo2.Demo1;

import Advanced.JDBC.Util.DBUtils;

import java.sql.SQLException;

public class Demo1A {
    public static void main(String[] args) {
        DBUtils db=new DBUtils();
        //设置9月份的注册时间s1
        String s1="2020-09-12 16:29:58";
        //设置9月1日以前的注册时间s2
        String s2="2020-08-06 15:32:31";
        int sum=0;
        try {
            //1.连接驱动
            db.getConnection();
            //2.定义sql语句
            String sql="insert into ms_memer(member_id,Uname,Password,Email,Sex,Mobile,Regtime,Lastlogin,Image) values (?,?,?,?,?,?,?,?,?)";
            for (int i = 0; i < 100; i++) {
                if(i<49){
                    //插入前50条9月份最后一次登录的数据
                    db.executeUpdate(sql,new String[]{null,"hs","123456","hs@qq.com","1","18872748895",s1,s1,"hs-vae"});
                }else {
                    //插入后50条9月1日之前最后一次登录的数据
                    db.executeUpdate(sql,new String[]{null,"vae","123456","hs@qq.com","0","18872748895",s2,s2,"hs-vae"});
                }
                ++sum;
            }
            System.out.println("已成功插入:"+sum+"条数据");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            db.closeAll();
        }
    }
}
