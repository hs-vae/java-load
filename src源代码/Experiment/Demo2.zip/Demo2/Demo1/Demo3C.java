package Experiment.Demo2.Demo1;

import Advanced.JDBC.Util.DBUtils;

import java.sql.ResultSet;
import java.sql.SQLException;

/*
    要求:编写存储过程查询出九月份有登陆过本系统会员信息要求查询出具体的会员名称和登陆时间
 */
public class Demo3C {
    public static void main(String[] args) {
        DBUtils db=new DBUtils();
        try {
            db.getConnection();
            String sql="select * from ms_memer where timestamp(Lastlogin) between ? and ?";
            ResultSet rs=db.executeQuery(sql,new String[]{"2020-08-31 23:59:59","2020-09-30 23:59:59"});
            System.out.println("---------9月份登录过本系统的会员信息-----------");
            System.out.println("  "+"会员名称"+"     "+"注册时间"+"           "+"最后一次登录时间");
            while (rs.next()){
                System.out.println(rs.getRow()+":"+"\t"
                        +rs.getString(2)+"\t"
                        +rs.getString(7)+"\t"
                        +rs.getString(8));
            }
            System.out.println("--------------------------------");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            db.closeAll();
        }
    }
}
